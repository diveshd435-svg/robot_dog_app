import 'package:flutter/material.dart';
import 'package:flutter_bluetooth_serial/flutter_bluetooth_serial.dart';
import 'dart:convert';

void main() => runApp(RobotDogApp());

class RobotDogApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: ControlPage(),
    );
  }
}

class ControlPage extends StatefulWidget {
  @override
  _ControlPageState createState() => _ControlPageState();
}

class _ControlPageState extends State<ControlPage> {
  BluetoothState bluetoothState = BluetoothState.UNKNOWN;
  BluetoothConnection? connection;
  bool connected = false;

  @override
  void initState() {
    super.initState();
    FlutterBluetoothSerial.instance.state.then((state) {
      setState(() => bluetoothState = state);
    });
  }

  void sendCommand(String cmd) {
    if (connected && connection != null) {
      connection!.output.add(utf8.encode(cmd));
      connection!.output.allSent;
    }
  }

  void connectToDevice() async {
    final BluetoothDevice? hc05 = await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => SelectBondedDevicePage(checkAvailability: false),
      ),
    );

    if (hc05 != null) {
      BluetoothConnection.toAddress(hc05.address).then((_connection) {
        connection = _connection;
        setState(() => connected = true);

        connection!.input!.listen(null).onDone(() {
          setState(() => connected = false);
        });
      });
    }
  }

  Widget btn(String label, String cmd) {
    return ElevatedButton(
      onPressed: () => sendCommand(cmd),
      child: Text(label, style: TextStyle(fontSize: 18)),
      style: ElevatedButton.styleFrom(minimumSize: Size(120, 60)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Robot Dog Controller")),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            children: [
              ElevatedButton(
                onPressed: connectToDevice,
                child: Text(connected ? "Connected" : "Connect to HC-05"),
              ),
              SizedBox(height: 20),

              btn("Forward", "F"),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  btn("Left", "L"),
                  SizedBox(width: 20),
                  btn("Right", "R"),
                ],
              ),
              btn("Backward", "B"),

              SizedBox(height: 20),
              btn("Sit", "S"),
              btn("Shake Hand", "H"),
              btn("Lie Down", "D"),
            ],
          ),
        ),
      ),
    );
  }
}

class SelectBondedDevicePage extends StatelessWidget {
  final bool checkAvailability;

  const SelectBondedDevicePage({required this.checkAvailability});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<BluetoothDevice>>(
      future: FlutterBluetoothSerial.instance.getBondedDevices(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

        return Scaffold(
          appBar: AppBar(title: Text("Select Device")),
          body: ListView(
            children: snapshot.data!
                .map((device) => ListTile(
                      title: Text(device.name ?? "Unknown"),
                      subtitle: Text(device.address),
                      onTap: () => Navigator.pop(context, device),
                    ))
                .toList(),
          ),
        );
      },
    );
  }
}